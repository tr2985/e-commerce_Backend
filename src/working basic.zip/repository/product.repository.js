// AQUI TRABAJAMOS CON EL MODELO DE PRODUCTOS....

const Product = require('../models/product.model');

// getAll Products es un metodo que creamos nosostros, consulta todos los productos

exports.getAllProducts = async() =>{
    return await Product.find();
}


exports.getProducts = async (id) => {
    return await Product.findById(id);
}



//  create product - product recibe de toda la data y ademas todas las
// caracteristcas de mongoose

exports.createProduct = async (data) => {
    const product = new Product(data);
    return await product.save();
}

// update product by id//

exports.updateProduct = async (id, data) => {

    return await Product.findByIdAndUpdate(id, data, { new: true });
}

// delete product by id//
exports.deleteProduct = async (id) => {

    return await Product.findByIdAndDelete(id);
}