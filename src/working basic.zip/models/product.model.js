const mongoose = require('mongoose');

const UserSchema = mongoose.Schema({

    name: {
        type: String, // initial captital letter for mongoose
        required: true,

    },

    price: Number,
    descripcion: String



});

module.exports = mongoose.model('Product', UserSchema);
